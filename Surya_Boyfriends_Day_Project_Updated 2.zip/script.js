const screens=[...document.querySelectorAll('.screen')];
function show(id){screens.forEach(s=>s.classList.toggle('active',s.id===id));window.scrollTo(0,0)}
document.querySelectorAll('[data-next]').forEach(b=>b.addEventListener('click',()=>show(b.dataset.next)));

const music=document.getElementById('music'), musicBtn=document.getElementById('musicBtn');
let musicStarted=false;
function startMusic(){ if(!musicStarted){music.volume=.25; music.play().catch(()=>{}); musicStarted=true;} }
document.body.addEventListener('click',startMusic,{once:true});
musicBtn.addEventListener('click',e=>{e.stopPropagation(); if(music.paused){music.play();musicBtn.innerHTML='♫ <span>Music</span>'}else{music.pause();musicBtn.innerHTML='🔇 <span>Muted</span>'}});

const questions=[
 ["What do I miss most about you?",["Your voice","Your hugs","Annoying you","Everything 😭"],3],
 ["After 8 months, what am I still waiting for?",["A first meeting","A lottery win","You to stop annoying me","All of the above"],0],
 ["What is my favourite thing about us?",["That we never talk","That distance hasn't stopped us","That you lose every argument","Free food"],1]
];
let qi=0;
function renderQ(){const q=questions[qi];document.getElementById('question').textContent=q[0];const a=document.getElementById('answers');a.innerHTML='';document.getElementById('quizResult').textContent='';q[1].forEach((x,i)=>{let b=document.createElement('button');b.textContent=x;b.onclick=()=>{document.getElementById('quizResult').textContent=i===q[2]?"Okayyy, you know us. 🥹❤️":"Wrong answer… but I still love you. 😭❤️";setTimeout(()=>{qi++;if(qi<questions.length)renderQ();else{document.getElementById('question').textContent="Final score: 10/10 in my heart.";a.innerHTML="";document.getElementById('quizResult').textContent="You passed the most important test: being my person. ♡";document.getElementById('toHearts').classList.remove('hidden')}},650)};a.appendChild(b)})}
renderQ(); document.getElementById('toHearts').onclick=()=>show('heartsGame');

let score=0, gameTimer;
function spawnHeart(){if(score>=20)return;const area=document.getElementById('gameArea'),h=document.createElement('span');h.className='falling-heart';h.textContent=['♡','♥','💗','💕'][Math.floor(Math.random()*4)];h.style.left=Math.random()*88+4+'%';h.style.top='-5%';h.onclick=()=>{score++;document.getElementById('score').textContent=score;h.remove();if(score>=20){clearInterval(gameTimer);document.getElementById('gameMessage').textContent="You caught all of them. But there is one heart you can't catch… because it's already yours. ❤️";document.getElementById('toDistance').classList.remove('hidden')}};area.appendChild(h);setTimeout(()=>h.remove(),2700)}
gameTimer=setInterval(spawnHeart,650); for(let i=0;i<3;i++)spawnHeart();
document.getElementById('toDistance').onclick=()=>show('distance');

document.getElementById('unlock').onclick=()=>{const code=document.getElementById('code').value.trim();if(code==="2501"){show('final')}else document.getElementById('codeResult').textContent="Hmm… that’s not our date. Try the day our story began. ❤️"};
document.getElementById('promise').onclick=()=>document.getElementById('promiseBox').classList.remove('hidden');
function promise(){document.getElementById('promiseResult').textContent="Then it's a promise. I'll be waiting for that hug. 🫂❤️";for(let i=0;i<18;i++){let h=document.createElement('span');h.className='heart';h.textContent='♥';h.style.left=Math.random()*100+'%';h.style.top=(60+Math.random()*30)+'%';h.style.animationDuration=(3+Math.random()*3)+'s';document.querySelector('.hearts').appendChild(h);setTimeout(()=>h.remove(),6000)}}
document.getElementById('yes').onclick=promise;document.getElementById('obvious').onclick=promise;
setInterval(()=>{let h=document.createElement('span');h.className='heart';h.textContent=['♡','♥','✦'][Math.floor(Math.random()*3)];h.style.left=Math.random()*100+'%';h.style.top='100%';h.style.fontSize=(10+Math.random()*14)+'px';h.style.animationDuration=(5+Math.random()*4)+'s';document.querySelector('.hearts').appendChild(h);setTimeout(()=>h.remove(),9000)},900);
