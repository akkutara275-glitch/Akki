# For Surya ♡

A little interactive Boyfriend's Day surprise from Akansha.

## How to use
1. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder to a GitHub repository.
2. Enable GitHub Pages from Settings → Pages → Deploy from branch → main → root.
3. Open the generated GitHub Pages link and send it to Surya.

## Personalise
The final unlock is set to **2501 (25 January)**, your anniversary date, in DDMM format.

The included `assets/our-song.wav` is an original gentle instrumental loop made for this page, so it does not rely on a copyrighted song.
